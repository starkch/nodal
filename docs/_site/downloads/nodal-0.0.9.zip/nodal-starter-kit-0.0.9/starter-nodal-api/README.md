# A Nodal Application

Prebuilt `starter-nodal-api` server corresponds to only the files generated from the `nodal new` command.

## Running Locally

This starter kit is intended to serve users looking for prebuilt versions of Nodal. This project contains a local version of Nodal, which makes available all Nodal command line APIs including generators, database, tasks, server, and polybit deployment.

You may use the local installation of Nodal by replacing any reference to `$ nodal ...` with `npm run nodal -- ...`.

Start your server with:

```sh
npm run nodal -- s
```

Your app should now be running on [localhost:3000](http://localhost:3000/).

## Nodal and npm

While this starter kit does not require NPM to get your Nodal server running, Nodal generators will still use NPM to install dependencies as necessary.

Welcome, and enjoy using [Nodal](http://nodaljs.com)!
