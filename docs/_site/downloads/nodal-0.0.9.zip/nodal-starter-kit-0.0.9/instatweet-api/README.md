# A Nodal Application

This is the `instatweet-api`, which corresponds to the instructions in the Nodal tutorial.

## Running Locally

This starter kit is intended to serve users looking for prebuilt versions of Nodal. This project contains a local version of Nodal, which makes available all Nodal command line APIs including generators, database, tasks, server, and polybit deployment.

While the tutorial instructions assume a global npm installation of Nodal, all Nodal command line methods are available through the local instance of Nodal included in this project.

You may use the local installation of nodal by replacing any reference to `$ nodal ...` with `npm run nodal -- ...`.

Start your server with:

```sh
npm run nodal -- s
```

Your app should now be running on [localhost:3000](http://localhost:3000/).

## Nodal and npm

While this starter kit does not require NPM to get your Nodal server running, Nodal generators will still use NPM to install dependencies as necessary.

Welcome, and enjoy using [Nodal](http://nodaljs.com)!
